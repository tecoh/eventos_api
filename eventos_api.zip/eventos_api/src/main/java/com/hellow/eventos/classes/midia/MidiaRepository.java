package com.hellow.eventos.classes.midia;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MidiaRepository extends JpaRepository<Midia,Integer> {
}
