package com.hellow.eventos.classes.evento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventoRepository extends JpaRepository<evento,Integer> {
}
